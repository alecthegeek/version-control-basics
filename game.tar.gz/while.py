# while loops

i = 0

while i < 10:
  i = i + 1
  print i
