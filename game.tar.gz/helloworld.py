# hello world

print "hello world!"