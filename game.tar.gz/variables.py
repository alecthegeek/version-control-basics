# variables

a = 4
b = 5

print a + b

c = 2
d = 6
e = c * d

print e