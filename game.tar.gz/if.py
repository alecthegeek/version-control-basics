# if statements

a = 4
b = 5

if a > b:
  print "true"
else:
  print "false"
