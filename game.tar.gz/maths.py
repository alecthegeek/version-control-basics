# maths

print 1 + 2
print 3 + 4 * 5